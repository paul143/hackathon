export const environment = {
  production: false,
  apiBaseUrl: 'https://your-api-id.execute-api.region.amazonaws.com/prod',
  cognito: {
    userPoolId: '<USER_POOL_ID>',
    clientId: '<APP_CLIENT_ID>',
    domain: '<your-domain>.auth.region.amazoncognito.com',
    redirectUri: 'https://your-frontend-domain/',
    scopes: ['openid','email','profile']
  }
};