import { Component } from '@angular/core';
@Component({
 selector: 'app-assistant',
 standalone: true,
 templateUrl: './assistant.component.html'
})
export class AssistantComponent {
 messages: {role:'user'|'assistant', text:string}[] = [];
 userInput = '';
 send() {
   if (!this.userInput.trim()) return;
   this.messages.push({role:'user', text:this.userInput});
   this.userInput='';
 }
}